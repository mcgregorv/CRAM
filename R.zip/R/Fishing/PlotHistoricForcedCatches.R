#these are summary plots of historic catch (not spatially)
this_run<-"Base"

nboxes<-30

this_path<-paste(DIR$'Base',"ATLANTISmodels\\",sep="")
plotPath<-paste(DIR$"Figures","CatchHistories\\",sep="")

catchYears<-seq(1900,2014); ny<-length(catchYears)

#read in groups csv file to get codes for fished groups
groupsDF<-read.csv(paste(this_path,"CRAM_groups.csv",sep="")); ng<-dim(groupsDF)[1]
catchCodes<-groupsDF$Code[groupsDF$IsFished==1]; ncg<-length(catchCodes)

catch_array<-read.csv(paste(DIR$'Tables',"ALLcatchHistories.csv",sep=""))
colnames(catch_array)[1]<-"Year"

totalByGroup<-colSums(catch_array[,-1],na.rm=TRUE)

nTopGroups<-6

#keep out top groups by catch and lump the rest into 'other'
topGroups<-names(sort(totalByGroup,decreasing = TRUE))[1:nTopGroups]
otherIndex<-!(colnames(catch_array) %in% c("Year",topGroups))
otherByYear<-rowSums(catch_array[,otherIndex],na.rm=TRUE)/1000 #turn to tonnes

top_catch_array<-cbind("Year"=catch_array$Year,catch_array[,colnames(catch_array) %in% topGroups]/1000,"Other"=otherByYear)
colnames(top_catch_array)<-c("Year", "Black oreo", "Hoki", "Ling", "Orange roughy", "Pelagic fish medium", "Smooth oreo", "Other")
# colnames(top_catch_array)<-c("Year", "Black oreo", "Hoki", "Ling", "Orange roughy", "Pelagic fish medium", "Smooth oreo", "Javelinfish", "Mesopelagic jelly-eaters","Other")

catchColors<-c(colorRampPalette(colors=c(myGold,myGreen,myAqua,myBlue,myPurple,myRed))(nTopGroups),myGrey)

catchDF<-melt(top_catch_array,id.var="Year")
bp<-ggplot(catchDF, aes(x = Year, y = value, fill = variable)) + 
  geom_bar(stat = "identity")

pdf(paste(plotPath,"TopCatchByYear.pdf",sep=""),height=5,width=7)
bp + scale_fill_manual(values=catchColors) + labs(y="Catch (tonnes)") + theme_igray() + 
  theme(axis.text=element_text(size=14),axis.title=element_text(size=14)) + guides(fill=guide_legend(title=""))
dev.off()

