library(nzPlot)

newNorthArrow<-function(long, lat) 
  {
    long1 <- long - diff(.nz$xlim) * 0.04
    long2 <- long + diff(.nz$xlim) *  0.04
    lat1 <- lat - 0.67 * diff(.nz$ylim) * 0.2
    lat2 <- lat + 0.33 * diff(.nz$ylim) *  0.2
    nz.arrows(long, lat1, long, lat2)
    nz.segments(long1, lat, long2, lat)
    nz.text(long, lat2 + diff(.nz$ylim) * 0.02, "N", cex=1.5)

}


pdf(paste(DIR$'Figures',"ChathamRiseNZPlotMap.pdf", sep=""), height=4, width=6)
par(mar=c(3,5,1,0),oma=c(1,1,1,1), cex.axis=0.6, cex.lab=0.6, cex=0.6)
nz(xlim = c(165, 187), ylim = c(-50, -34),xlab=" ",ylab=" ",cex=thisCex,fill.col="DarkOliveGreen3")
nz.depth(contour = 1000, col="lightblue"); nz.depth(contour = 500, col="lightblue"); nz.depth(contour = 200, col="lightblue");
# tidy up land
nz.polygon(nz.coast$long, nz.coast$lat,  col = "DarkOliveGreen3",  border = T, xpd = F)
nz.polygon(nz.islands$long, nz.islands$lat,  col = "DarkOliveGreen3",  border = T, xpd = F)
nz.text("200 m, 500 m and\n1000 m contours",x=183.8, y=-34.8, col="lightblue", cex=1, font=2)
nz.text("Chatham Rise", x=179, y=-43.4, col="black", font=2, cex=1.5)
nz.text("South\nIsland", x=169.7, y=-44.55, cex=1)
nz.text("North\nIsland", x=175.8, y=-38.7, cex=1)
newNorthArrow(long=186, lat=-47.5)
dev.off()

pdf(paste(DIR$'Figures',"ChathamRiseNZPlotMapOriginal.pdf", sep=""), height=4, width=6)
par(mar=c(3,5,1,0),oma=c(1,1,1,1))
nz(xlim = c(165, 187), ylim = c(-50, -34),xlab=" ",ylab=" ",cex=thisCex,fill.col="DarkOliveGreen3", box.lwd=NA)
nz.depth(contour = 1000, col="lightblue"); nz.depth(contour = 500, col="lightblue"); nz.depth(contour = 200, col="lightblue");
# tidy up land
nz.polygon(nz.coast$long, nz.coast$lat,  col = "DarkOliveGreen3",  border = T, xpd = F)
nz.polygon(nz.islands$long, nz.islands$lat,  col = "DarkOliveGreen3",  border = T, xpd = F)
nz.text("200 m, 500 m and\n1000 m contours",x=183.8, y=-34.8, col="lightblue", cex=0.6, font=2)
nz.text("Chatham Rise", x=179, y=-43.4, col="black", font=2)
nz.text("South\nIsland", x=169.7, y=-44.5, cex=0.6)
nz.text("North\nIsland", x=175.8, y=-38.7, cex=0.6)
dev.off()