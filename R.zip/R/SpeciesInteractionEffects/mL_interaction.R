source(paste(DIR$'General functions',"createSensitivityRunADD.R",sep=""))
source(paste(DIR$'General functions',"get_biol_vector.R",sep=""))

this_run<-"base"; runLength<-"short"

## adds mortality using mL - hence, reducing each group in turn with the goal being to establish influence and flow-on effects
thisPath<-paste(DIR$'Base',"ATLANTISmodels\\",this_run,"\\",sep="")

#variables to edit
editVar<-"XXX_mL"

proportionalChange<-FALSE #set to true if want the existing values to be multiplied by the change values, FALSE if the change values replace the existing ones
nextLine<-TRUE #some paramters are on the same line as the parameter name (in which case set this to FALSE), some are the next line

isVector<-TRUE

groupsFileName<-"..\\CRAM_Groups"
biolFileName<-"..\\CRAM_BH_hybrid_biol"
forceFile<-"CRAM_forceBURNIN1865"

groupsDF<-read.csv(paste(thisPath,groupsFileName,".csv", sep=""))
ageGroups<-as.character(groupsDF$Code[groupsDF$NumCohorts>1]); ng<-length(ageGroups)

changeVectorIndex<-c(1,2) #V A and B
varMax<-0.1

changes<-c(2.8e-7, 1.4e-5, 2.8e-4) #
## to get M per year approx
lapply(changes, FUN=function(x){(-1)*365 * log(1-x)})

for(g in 1:ng){
  
  editGroups<-ageGroups[g]
  version<-paste("Sens",editGroups,sep="")
  
  createSensitivityRunADD(this_run,runLength,thisPath,editVar,version,editGroups,runPrmFile="CRAM_base_run50yr",changes,proportionalChange,nextLine,isVector,changeVectorIndex=changeVectorIndex,groupsFileName,biolFileName,varMax,ICfile="CRAM_input_short.nc", forceFile=forceFile)
  
}

#create file to run them all
fileName<-paste(thisPath,"Runthemall_Sens",editVar,sep="")
cat("", file=fileName, append=FALSE)
for(g in 1:ng){
  thisCode<-ageGroups[g]
  this_fileName<-paste("RunMulti_XXX_mLSens", thisCode,sep="")
  cat(paste("dos2unix ",this_fileName,"\n", sep=""), file= fileName, append = TRUE)
}
for(g in 1:ng){
  thisCode<-ageGroups[g]
  this_fileName<-paste("RunMulti_XXX_mLSens", thisCode,sep="")
  cat(paste("./",this_fileName,"\n", sep=""), file= fileName, append = TRUE)
}