#the ROMS variables we have are for XX years
#this script do some initial plots.
library(ggmap)
library(rgdal)
library(gtable)
library(maps)
library(mapdata)
library(rgeos)
source(paste(DIR$'General functions',"\\get_first_number.R",sep=""))
source(paste(DIR$'General functions',"formatShape.R",sep=""))
source(paste(DIR$'General functions',"myRounding.R",sep=""))

getColor<-function(x,thisMax){
  thisCol<-"white"
  if(!is.na(x) & x>0){
    if(x<thisMin){x<-thisMin}
    y<-round((x-thisMin)/(thisMax-thisMin),2)*100+1
    thisCol<-thisColRamp[y]
  }
  return(thisCol)
}
plotGrid<-function(x,y){
  thisX<-c(x-0.5,x-0.5,x+0.5,x+0.5); thisY<-c(y-0.5,y+0.5,y+0.5,y-0.5)
  thisCol<-plotColour[x,y]
  if(length(thisCol)>0){
    polygon(x=thisX,y=thisY,col=thisCol,border=NA)
  }
  return(NULL)
}

basePath<-paste(DIR$'Base',"ATLANTISmodels\\",sep="")

Version<-"D"
Version<-"B"
# outPath<-paste(basePath,"base\\ROMS1yearRepeat\\",sep="")
# outPath<-paste(basePath,"base\\ouputROMS",Version,"\\",sep="")
outPath<-paste(basePath,"base\\outputROMS",Version,"\\",sep="")
dataOutPath<-paste(basePath,"BootstrapROMS\\modelOut",Version,"_", sep="")

plotPath<-paste(DIR$'Figures',"ROMS\\",Version,sep="")

nruns<-50; nts<-51; burnin<-35 ## this is for bootstrap ROMS
# nruns<-9; nts<-51; burnin<-35 ##this is for repeat each ROMS

nl<-6; nb<-30

plotGrid<-function(x,y){
  thisX<-c(x-0.5,x-0.5,x+0.5,x+0.5); thisY<-c(y-0.5,y+0.5,y+0.5,y-0.5)
  thisCol<-plotColour[x,y]
  if(length(thisCol)>0){
    polygon(x=thisX,y=thisY,col=thisCol,border=NA)
  }
  return(NULL)
}

#get _N tracers
BaseNC.nc<-nc_open(paste(outPath, "outputROMSBootstrap",Version,"1\\output.nc",sep=""))
allTracers<-names(BaseNC.nc$var)
thisVol<-ncvar_get(BaseNC.nc, "volume"); nlayers<-dim(thisVol)[1]; nts<-dim(thisVol)[3]
x<-grep("_N",allTracers); temp<-allTracers[x]
y<-grep("Nums",temp, invert = TRUE); Ntracers<-temp[y]; ntracers<-length(Ntracers)

#set up array to store outputs
storeTracers<-array(NA, dim=c(nruns, ntracers,nts)); storeTracersByCell<-array(NA, dim=c(nruns, ntracers,nl,nb,nts))
storeTemperature<-array(NA,dim=c(nruns,nl,nb,nts)); 
store_nts<-rep(NA,nruns)
for(r in 1:nruns){
  cat(r," -- ")
  # thisOutPath<-paste(outPath,"outputBASE50yr",r,"\\",sep="")
  thisOutPath<-paste(outPath, "outputROMSBootstrap",Version,r,"\\",sep="")
  thisOutFile<-paste(thisOutPath,"output.nc",sep="")
  ThisNC.nc<-nc_open(thisOutFile)
  thisVol<-ncvar_get(ThisNC.nc,"volume")
  thisTracer<-"Temp"
  thisData<-ncvar_get(ThisNC.nc, thisTracer); this_nts<-dim(thisData)[3]
  storeTemperature[r,,,1:min(nts,this_nts)]<-thisData[,,1:min(nts,this_nts)]
  store_nts[r]<-this_nts
  for(t in 1:ntracers){
    thisTracer<-Ntracers[t]; thisData<-ncvar_get(ThisNC.nc, thisTracer)
    if(length(dim(thisData))==3){
      xx<-apply(thisData*thisVol,3,sum)*mg_2_tonne*X_CN
      yy<-thisData*thisVol*mg_2_tonne*X_CN
      storeTracersByCell[r,t,,,1:min(nts,this_nts)]<-yy[,,1:min(nts,this_nts)]
    } else{
      xx<-apply(thisData*thisVol[nl,,],2,sum)*mg_2_tonne*X_CN
      yy<-thisData*thisVol[nl,,]*mg_2_tonne*X_CN
      storeTracersByCell[r,t,nl,,1:min(nts,this_nts)]<-yy[,1:min(nts,this_nts)]
    }
    storeTracers[r,t,1:min(nts,this_nts)]<-xx[1:min(nts,this_nts)]
  }
}


#write them out - commented out so only write out if intending to
# save(list=c("storeTracers", "storeTracersByCell", "storeTemperature", "store_nts"),file=paste(dataOutPath,"modelTracers",sep=""))

# 
# load(paste(dataOutPath,"modelTracers",sep="")); ##to bring "storeTracers", "storeTracersByCell", "storeTemperature", "store_nts"
# ## . dim = dim=c(nruns, ntracers, nyears), c(nruns, ntracers,10, nyears), c(nruns, ntracers,10, nyears), c(nruns, ntracers, nyears) resp.

