makeBlankPlot<-function(){
  plot(1,type="n",xlab="",ylab="",xaxt="n",yaxt="n",bty="n")
}