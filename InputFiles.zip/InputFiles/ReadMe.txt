Used in the validation write up paper and SSR paper

used Atlantis 
#
#Atlantis2 Updated to Version 6262M
#
#
#
#Atlantis path https://svnserv.csiro.au/svn/ext/atlantis/Atlantis/trunk/atlantis
#
#
#
#Atlantis SVN Last Change Date 2017-11-29 18:28:29 +1300 (Wed, 29 Nov 2017)

#